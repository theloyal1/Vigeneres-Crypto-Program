package com.example.vigenerescryptoprogram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void criptografar(View view) {
        EditText texto = findViewById(R.id.editTextTexto);
        String txt = texto.getText().toString();
        EditText senha = findViewById(R.id.editTextChave);
        String chave = senha.getText().toString();
        String resposta = "";

        for(int i=0, j=0; i<txt.length(); i++) {
            char c = txt.charAt(i);
            resposta += (char) (((c + chave.charAt(j) - 2 * 'a') % 26 + 'a') + 1);
            j = ++j % chave.length();
        }

        TextView resultado = findViewById(R.id.textViewCriptografia);
        resultado.setText(resposta);
    }
}